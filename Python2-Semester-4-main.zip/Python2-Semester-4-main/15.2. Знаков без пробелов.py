s=input()
c=0
for a in s:
    if a != ' ' and a !='\t':
        c+=1
print(c)