buy = list()
n = int(input())
for i in range(n):
    thing = input()
    nn = int(input())
    buy.append(thing, nn, sep=' ')
for i in range(n):
    print(n[-1:0])