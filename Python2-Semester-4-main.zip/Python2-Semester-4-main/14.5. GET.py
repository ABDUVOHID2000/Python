import re
print(re.search('text=(\w+)&',input())[1])
