s= input()
if s[0].lower() == 'а':
    print('ДА')
else:
    print('НЕТ')