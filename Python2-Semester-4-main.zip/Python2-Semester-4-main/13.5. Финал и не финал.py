N = int(input())
kom = []
res = []
for i in range(N):
    k = input()
    kom.append(k)
    r = int(input())
    res.append(r)
res_2 = reversed(sorted(res))
