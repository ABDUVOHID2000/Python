a = input()
for i in range(len(a)):
    if a[i] == 'A' or 'a':
        print(' * ')
        print('* *')
        print('***')
        print('* *')
        print('* *')
    if a[i] == 'B' or 'b':
        print('** ')
        print('* *')
        print('**')
        print('* *')
        print('**')
    if a[i] == 'C' or 'c':
        print(' *')
        print('* *')
        print('*  ')
        print('* *')
        print(' *')