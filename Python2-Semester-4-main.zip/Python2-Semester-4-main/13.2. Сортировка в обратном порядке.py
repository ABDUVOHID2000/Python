print(*sorted((int(input("Введите  число: ")) 
for _ in range(int(input("Введите кол-во чисел: ")))), reverse = True), sep = "\n")