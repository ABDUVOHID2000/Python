a = input()

while len(a) >= 1:
    print(a)
    a =a[1:-1]
    
    