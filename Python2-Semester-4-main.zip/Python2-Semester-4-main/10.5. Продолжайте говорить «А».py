while True:
    a = input()
    b = a[0]
    if b == "а" or b =="А":
        print("Congrats!")
    else :
        print("Error")
        break